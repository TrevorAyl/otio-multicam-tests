#!/usr/bin/env python3
"""Generate all 16 sources from source_spec.json. No network or paid services.
Requires ffmpeg with flite, ffprobe, Python 3, numpy and Pillow.
Camera audio is PCM: A/G separate mono streams, ordinary stereo cameras one stereo stream.
"""
import concurrent.futures, hashlib, json, math, shutil, struct, subprocess, tempfile, wave
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent; MEDIA=ROOT/'Media'; CACHE=ROOT/'Speech'; WORK=ROOT/'Work'
for p in (MEDIA,CACHE,WORK):p.mkdir(exist_ok=True)
SPEC=json.loads((ROOT/'source_spec.json').read_text());SOURCES=SPEC['sources']; MAP=SPEC['audio']
SR=48000;FPS=25;SECONDS=180;N=SR*SECONDS;W=1280;H=720
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
if not Path(FONT).exists():FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
SYNC_TIMES=[15,45,90,150]; LOG={'sources':{},'ident_schedule':{},'audio_checks':{},'buses':{}}

def run(cmd,**kw):
 p=subprocess.run(cmd,check=False,capture_output=True,**kw)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')[-6000:])
 return p
def ff(*args,**kw):return run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y',*map(str,args)],**kw)
def probe(p):return json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]).stdout)
def decoded_audio(p,stream=None):
 # Keep long binary decodes out of stdout pipes as well as long encoding inputs.
 with tempfile.NamedTemporaryFile(dir=WORK,suffix='.f32',delete=False) as f:raw=Path(f.name)
 try:
  args=['-i',p]
  if stream is not None:args+=['-map',f'0:a:{stream}']
  ff(*args,'-f','f32le',raw)
  return np.fromfile(raw,dtype='<f4')
 finally:raw.unlink(missing_ok=True)
def tc(fr):
 fr=int(fr);return f'{fr//90000:02}:{fr//1500%60:02}:{fr//25%60:02}:{fr%25:02}'
def spoken(text,voice='slt'):
 text=text.replace('VO','Vee Oh').replace('VT','Vee Tee').replace('CAM ','Camera ')
 key=hashlib.sha256((voice+text).encode()).hexdigest()[:16];p=CACHE/(key+'.wav');txt=CACHE/(key+'.txt')
 if not p.exists():
  txt.write_text(text+'\n');ff('-f','lavfi','-i',f'flite=textfile={txt}:voice={voice}','-ar',SR,'-ac',1,'-c:a','pcm_s24le',p)
 data=np.frombuffer(ff('-i',p,'-f','f32le','-').stdout,dtype='<f4').copy()
 peak=float(np.max(np.abs(data)))
 if peak:data*=np.float32(.23/peak)
 return data
def blank():return np.zeros(N,dtype=np.float32)
def put(a,data,t,gain=1):
 i=round(t*SR);e=min(len(a),i+len(data));a[i:e]+=data[:e-i]*np.float32(gain)
def phrase(text,start,end,voice='slt'):
 data=spoken(text,voice);maxlen=round((end-start)*SR)
 if len(data)>maxlen:raise RuntimeError('Speech exceeds event window: '+text)
 a=blank();put(a,data,start)
 # Repeat the sentence after a short pause when it fits, keeping source audible through fader moves.
 if len(data)*2+round(.3*SR)<=maxlen:put(a,data,start+len(data)/SR+.3)
 return a
def tone(start,end,freq,amp=.03,phase=0):
 a=blank();i=round(start*SR);e=round(end*SR);t=np.arange(e-i,dtype=np.float64)/SR
 a[i:e]=(amp*np.sin(2*np.pi*freq*t+phase)).astype(np.float32)
 fade=min(round(.02*SR),(e-i)//2);a[i:i+fade]*=np.linspace(0,1,fade,dtype=np.float32);a[e-fade:e]*=np.linspace(1,0,fade,dtype=np.float32)
 return a
def bus_save(device,arrays):
 for i,a in enumerate(arrays):
  if np.max(np.abs(a))>.65:raise RuntimeError(f'Bus too loud: {device} {i+1}')
  np.save(WORK/f'{device}_{i+1:02}.npy',a.astype(np.float32,copy=False))

def master_audio():
 print('Building common sync clock, dialogue and studio buses',flush=True)
 rng=np.random.default_rng(427)
 # Low-level non-repeating deterministic bed, identical event positions in all scratch/mix sources.
 sync=(rng.standard_normal(N).astype(np.float32)*.0015)
 for ix,st in enumerate(SYNC_TIMES):
  for j in range(ix+1):
   sig=.15*np.sin(2*np.pi*1000*np.arange(round(.04*SR))/SR);put(sync,sig,st+j*.16)
  put(sync,spoken(SPEC['events'][ix][5]),st+.8,.5)
 bob=phrase('Bob, passage one. My pre fader microphone remains steady while the mix fader changes.',25,35,'rms')
 jim=phrase('Jim, passage two. Keep my sound continuous while you change camera angles.',95,105,'slt')
 p1=phrase('Player one speaking. This is the left contestant microphone before its fader.',55,65,'slt')
 p2=phrase('Player two speaking. Listen to my pre fader source and the contestant submix.',115,125,'rms')
 guest1=phrase('Guest one speaking. Camera G, channel nine.',135,140,'rms')
 guest2=phrase('Guest two speaking. Camera G, channel ten.',155,160,'slt')
 greenL=phrase('Left green room. This is the left automix output.',75,83,'rms')
 greenR=phrase('Right green room. This is the right automix output.',125,133,'slt')
 vo=phrase('Voice over cue. This is an original synthetic voice over on the stereo voice over feed.',160,170,'slt')
 vt=phrase('Vee Tee cue. This is recorded playback. It belongs in the main mix and is absent from the mix minus Vee Tee.',100,110,'rms')
 bpost=bob.copy();bpost[28*SR:32*SR]*=np.float32(10**(-12/20))
 p2post=p2.copy();p2post[118*SR:122*SR]*=np.float32(10**(-12/20))
 audL=blank();audR=blank()
 for a in (audL,audR):a[35*SR:40*SR]=rng.standard_normal(5*SR).astype(np.float32)*.015
 audid=spoken('Audience cue.');put(audL,audid,35,.35);put(audR,audid,35.025,.35)
 musicL=blank();musicR=blank();notes=[220,261.6256,329.6276,293.6648,246.9417]
 for j in range(10):
  st=65+j;en=st+1
  musicL+=tone(st,en,notes[j%5],.04);musicR+=tone(st,en,notes[(j+2)%5],.04)
 mus=spoken('Music cue.');put(musicL,mus,65,.3);put(musicR,mus,65.018,.3)
 vtL=vt*.65;vtR=np.roll(vt,round(.018*SR))*.65
 voL=vo*.65;voR=np.roll(vo,round(.012*SR))*.65
 subL=p1*.6+p2post*.2;subR=p1*.2+p2post*.6
 autoL=p1*.55+guest1*.35;autoR=p2post*.55+guest2*.35
 micL=bpost*.5+jim*.2+subL+guest1*.3+guest2*.1+greenL*.3+greenR*.1
 micR=bpost*.2+jim*.5+subR+guest1*.1+guest2*.3+greenL*.1+greenR*.3
 fx=phrase('Effect one.',110,114,'slt')*.5
 for j in range(5):fx+=tone(110+j*.25,110+j*.25+.08,900+j*130,.08)
 mainL=micL+audL+musicL+vtL+voL+fx*.2+sync*.35
 mainR=micR+audR+musicR+vtR+voR+fx*.2+sync*.35
 mmL=micL+audL+voL+fx*.2+sync*.35;mmR=micR+audR+voR+fx*.2+sync*.35
 maL=micL+musicL+vtL+voL+fx*.2+sync*.35;maR=micR+musicR+vtR+voR+fx*.2+sync*.35
 # Independent numeric checks, outside later utility ident overlays.
 assert np.max(np.abs((mainL-mmL)-(musicL+vtL)))<1e-6
 assert np.max(np.abs((mainR-maR)-audR))<1e-6
 assert np.max(np.abs(bpost[28*SR:32*SR]-bob[28*SR:32*SR]*np.float32(10**(-12/20))))<1e-6
 LOG['buses']={'mix_minus_grams_vt':'checked','mix_minus_audience':'checked','pre_post_fader':'checked'}
 bus_save('CAM_A',[mainL,mainR,audL,audR,bob,jim,micL,micR,p1,p2,musicL,musicR,subL,subR,voL,voR])
 bus_save('CAM_G',[mmL,mmR,vtL,vtR,maL,maR,greenL,greenR,guest1,guest2,autoL,autoR])
 roomL=rng.standard_normal(N).astype(np.float32)*.002;roomR=rng.standard_normal(N).astype(np.float32)*.002
 recL=bpost*.5+jim*.2+roomL+fx*.3+sync*.3;recR=bpost*.2+jim*.5+roomR+fx*.3+sync*.3
 bus_save('REC_MAIN',[bob,jim,roomL,roomR,sync,fx,recL,recR]);bus_save('REC_BACKUP',[recL,recR]);bus_save('PGM',[mainL,mainR])
 scratch=(mainL+mainR)*.25+sync*.6;bus_save('SCRATCH',[scratch,scratch])

def pcm_wav(p,array,channels=1,metadata=None):
 # Write PCM directly in bounded chunks; no long binary subprocess pipes.
 temp=Path(str(p)+'.tmp.wav');a=np.asarray(array).reshape(-1,channels)
 with wave.open(str(temp),'wb') as wf:
  wf.setnchannels(channels);wf.setsampwidth(3);wf.setframerate(SR)
  for start in range(0,len(a),65536):
   chunk=np.rint(np.clip(a[start:start+65536],-1,1-2**-23)*2**23).astype(np.int32)
   packed=np.empty(chunk.shape+(3,),dtype=np.uint8)
   for byte in range(3):packed[...,byte]=(chunk>>(8*byte))&255
   wf.writeframesraw(packed.tobytes())
 assert temp.stat().st_size==44+len(a)*channels*3
 if metadata:
  bext=bytearray(602)
  for key,offset,length in [('description',0,256),('originator',256,32),('origination_date',320,10),('origination_time',330,8)]:
   b=str(metadata.get(key,'')).encode('ascii')[:length];bext[offset:offset+len(b)]=b
  struct.pack_into('<Q',bext,338,int(metadata['time_reference']));struct.pack_into('<H',bext,346,1)
  bwf=Path(str(p)+'.bwf.wav')
  with temp.open('rb') as src,bwf.open('wb') as dst:
   header=src.read(12);dst.write(b'RIFF'+struct.pack('<I',temp.stat().st_size+610-8)+b'WAVE');dst.write(b'bext'+struct.pack('<I',602)+bext);shutil.copyfileobj(src,dst)
  temp.unlink();bwf.replace(p)
 else:temp.replace(p)
 assert abs(float(probe(p)['format']['duration'])-len(a)/SR)<1/SR,'PCM file duration mismatch'

def source_audio(s):
 device=s[1];count=int(s[15]);start=float(s[5]);duration=float(s[7]);length=round(duration*SR);i=round(start*SR); lag=round(float(s[13])*SR/FPS)
 rows=sorted([r for r in MAP if r[0]==device],key=lambda r:r[1]);assert len(rows)==count
 dest=WORK/s[0];dest.mkdir(exist_ok=True);paths=[];schedule=[]
 if not count:return paths
 fileid=spoken(s[18]);assert len(fileid)/SR<3
 # Skip repeated idents overlapping sync cue / mix-minus test windows.
 reserved=[(t,t+6) for t in SYNC_TIMES]+[(35,40),(65,75),(100,110),(28,32),(118,122)]
 for ix,row in enumerate(rows):
  base_device=device if device in ['CAM_A','CAM_G','REC_MAIN','REC_BACKUP','PGM'] else 'SCRATCH'
  base_ch=ix+1 if base_device!='SCRATCH' else min(ix+1,2)
  base=np.load(WORK/f'{base_device}_{base_ch:02}.npy',mmap_mode='r');data=np.array(base[i:i+length],dtype=np.float32)
  put(data,fileid,1,.6)
  ident=spoken(row[4]);assert len(ident)/SR<=8
  positions=[]
  for st in np.arange(float(row[5]),duration,float(row[6])):
   stop=st+len(ident)/SR;evstart=start+st;evstop=start+stop
   if stop>duration or any(evstart<b and evstop>a for a,b in reserved):continue
   put(data,ident,float(st),.45 if base_device=='SCRATCH' else 1);positions.append(round(float(st),3))
  if lag>0:data=np.concatenate([np.zeros(lag,dtype=np.float32),data[:-lag]])
  assert len(data)==length and np.max(np.abs(data))<.95
  p=dest/f'A{ix+1:02}.wav';pcm_wav(p,data);paths.append(p)
  schedule.append({'channel':ix+1,'name':row[2],'ident_local_seconds':positions,'ident_duration_seconds':len(ident)/SR,'audio_lag_samples':lag})
 LOG['ident_schedule'][s[0]]=schedule
 return paths

def camera(s):
 paths=source_audio(s);dur=float(s[7]);startframe=round(float(s[5])*FPS);color={'Red':'0x6b1c2a','Green':'0x16553c','Blue':'0x1c3d72','Orange':'0x773b18','Purple':'0x54245e','Cyan':'0x17545b','Yellow':'0x66570d','Grey':'0x343b46'}[s[17]]
 fp=FONT.replace(':','\\:')
 def dt(text,y,size=34):return f"drawtext=fontfile='{fp}':text='{text}':fontsize={size}:fontcolor=white:x=50:y={y}"
 def clock(label,tcstart,y):return dt(label,y)+f",drawtext=fontfile='{fp}':timecode='{tcstart.replace(':',chr(92)+':')}':r=25:fontsize=38:fontcolor=white:x=370:y={y}"
 filters=['drawgrid=w=160:h=90:t=1:color=white@0.1',dt(s[1]+'   /   '+s[0],45,58),clock('TRUE EVENT TC',tc(900000+startframe),140)]
 if s[8]=='None':filters.append(dt('RECORDED TC   NONE',205,38))
 else:filters.append(clock('RECORDED TC',s[11],205))
 filters += [dt(f'{int(s[15])} audio channels   Audio lag {int(s[13])} frames',280,30),dt('Event frame %{eif\\:n+'+str(startframe)+'\\:d\\:6}',340,38),f"drawtext=fontfile='{fp}':text='+':fontsize=85:fontcolor=white:x='80+mod((t+{s[5]})*100,1100)':y=450"]
 flash='+'.join(f'eq(n+{startframe},{t*FPS})' for t in SYNC_TIMES);filters.append(f"drawbox=x=0:y=0:w=iw:h=ih:color=white:t=fill:enable='{flash}'")
 args=['-f','lavfi','-i',f'color=c={color}:s={W}x{H}:r=25:d={dur}']
 for p in paths:args+=['-i',p]
 args+=['-map','0:v:0']
 if len(paths)==2 and s[16]=='Stereo':
  args+=['-filter_complex_threads','1','-filter_complex','[1:a][2:a]amerge=inputs=2[a]','-map','[a]']
 else:
  for ix in range(len(paths)):args+=['-map',f'{ix+1}:a:0']
 args+=['-vf',','.join(filters),'-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-g','25','-c:a','pcm_s24le','-ar',SR,'-movflags','+faststart','-threads','2','-t',dur,'-metadata',f'comment=Angle {s[1]}; true event start {s[5]} seconds; TC error {s[9]} frames; audio lag {s[13]} frames']
 if s[8]!='None':args+=['-timecode',s[11]]
 else:args+=['-write_tmcd','0']
 if len(paths)>2:
  for ix,row in enumerate(sorted([r for r in MAP if r[0]==s[1]],key=lambda r:r[1])):args+= [f'-metadata:s:a:{ix}',f'title=A{ix+1} {row[2]}',f'-metadata:s:a:{ix}',f'handler_name=A{ix+1} {row[2]}']
 output=MEDIA/s[4]
 print('Encoding '+s[4],flush=True);ff(*args,output);print('Encoded '+s[4],flush=True)

def recorder(s):
 paths=source_audio(s);arrays=[]
 for p in paths:arrays.append(decoded_audio(p))
 ref=round(float(s[10])/FPS*SR)
 pcm_wav(MEDIA/s[4],np.column_stack(arrays),len(paths),{'time_reference':ref,'description':f'Synthetic {s[1]}; channel order per workbook','originator':'OTIO synthetic multicam test','origination_date':'2026-10-13','origination_time':s[11][:8]})
 print('Encoded '+s[4],flush=True)

def graphics():
 print('Encoding synchronised Graphics Fill and Key',flush=True)
 scale=2;card=Image.new('RGBA',(1050*scale,125*scale),(0,0,0,0));d=ImageDraw.Draw(card)
 d.rounded_rectangle((0,0,1049*scale,124*scale),radius=14*scale,fill=(18,54,96,255));d.rectangle((0,0,12*scale,124*scale),fill=(242,182,45,255))
 d.text((32*scale,15*scale),'MULTICAMERA TEST',font=ImageFont.truetype(FONT,40*scale),fill='white')
 d.text((32*scale,72*scale),'SYNCHRONISED GRAPHICS FILL AND KEY',font=ImageFont.truetype(FONT,26*scale),fill=(220,232,246,255))
 card.resize((1050,125),Image.Resampling.LANCZOS).save(WORK/'card.png')
 fp=FONT.replace(':','\\:');active="between(t,10,49.999)+gte(t,85)"
 graph=(f"[0:v][1:v]overlay=x='65+25*sin(t*0.8)':y=550:enable='{active}':format=auto:alpha=straight,format=rgba[g];"
       f"[g]drawtext=fontfile='{fp}':text='Frame %{{eif\\:n\\:d\\:4}}':fontsize=40:fontcolor=white:x='850+45*sin(t)':y=360:enable='gte(t,85)',split[f][a];"
       '[f]format=yuv422p10le[fill];[a]alphaextract,format=yuv422p10le[key]')
 common=['-an','-c:v','prores_ks','-profile:v','3','-pix_fmt','yuv422p10le','-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709','-timecode','10:00:00:00','-threads','2','-t',180]
 ff('-filter_complex_threads','1','-f','lavfi','-i','color=c=black@0:s=1280x720:r=25:d=180,format=rgba','-loop','1','-framerate','25','-i',WORK/'card.png','-filter_complex',graph,'-map','[fill]',*common,MEDIA/'GF01.mov','-map','[key]',*common,MEDIA/'GK01.mov')
 print('Encoded graphics pair',flush=True)

CUTS=[('A01',0,20),('B01',20,40),('C01',40,60),('D01',60,90),('C02',90,120),('F02',120,130),('A01',130,140),('F03',140,160),('E01',160,180)]
def programme():
 print('Encoding switched programme with continuous stereo main mix',flush=True)
 s=next(x for x in SOURCES if x[0]=='P01');paths=source_audio(s)
 args=[];graphs=[]
 for ix,(fid,start,stop) in enumerate(CUTS):
  src=next(x for x in SOURCES if x[0]==fid);local=start-float(src[5]);assert local>=0 and stop<=float(src[6])
  args+=['-i',MEDIA/src[4]];graphs.append(f'[{ix}:v]trim=start_frame={round(local*25)}:end_frame={round((stop-float(src[5]))*25)},setpts=PTS-STARTPTS[v{ix}]')
 args+=['-i',paths[0],'-i',paths[1]]
 graphs+=[''.join(f'[v{i}]' for i in range(len(CUTS)))+f'concat=n={len(CUTS)}:v=1:a=0[v]',f'[{len(CUTS)}:a][{len(CUTS)+1}:a]amerge=inputs=2[a]']
 ff(*args,'-filter_complex_threads','1','-filter_complex',';'.join(graphs),'-map','[v]','-map','[a]','-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p','-c:a','pcm_s24le','-timecode','10:00:00:00','-movflags','+faststart','-threads','2','-t',180,MEDIA/'P01.mov')
 # Separate viewing preview with external key/fill composited; source P01 stays clean.
 graph='[2:v]format=gray[k];[1:v]format=rgb24[f];[f][k]alphamerge[fg];[0:v][fg]overlay=format=auto,format=yuv420p[v]'
 ff('-i',MEDIA/'P01.mov','-i',MEDIA/'GF01.mov','-i',MEDIA/'GK01.mov','-filter_complex_threads','1','-filter_complex',graph,'-map','[v]','-map','0:a:0','-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-b:a','160k','-movflags','+faststart','-threads','2','-t',180,ROOT/'Programme_Composite_Preview.mp4')
 print('Encoded programme and preview',flush=True)

def bext_reference(p):
 with open(p,'rb') as f:
  assert f.read(4)==b'RIFF';f.read(4);assert f.read(4)==b'WAVE'
  while True:
   tag=f.read(4)
   if not tag:raise RuntimeError('BWF bext chunk missing')
   size=struct.unpack('<I',f.read(4))[0]
   if tag==b'bext':f.seek(338,1);return struct.unpack('<Q',f.read(8))[0]
   f.seek(size+(size%2),1)
def verify():
 print('Verifying all source durations, metadata and channel samples',flush=True)
 for s in SOURCES:
  if s[15] and s[0] not in LOG['ident_schedule']:
   rows=sorted([r for r in MAP if r[0]==s[1]],key=lambda r:r[1]);schedule=[]
   reserved=[(t,t+6) for t in SYNC_TIMES]+[(35,40),(65,75),(100,110),(28,32),(118,122)]
   for row in rows:
    ident=spoken(row[4]);positions=[]
    for st in np.arange(float(row[5]),float(s[7]),float(row[6])):
     stop=st+len(ident)/SR;evstart=float(s[5])+st;evstop=float(s[5])+stop
     if stop>float(s[7]) or any(evstart<b and evstop>a for a,b in reserved):continue
     positions.append(round(float(st),3))
    schedule.append({'channel':row[1],'name':row[2],'ident_local_seconds':positions,'ident_duration_seconds':len(ident)/SR,'audio_lag_samples':round(float(s[13])*SR/FPS)})
   LOG['ident_schedule'][s[0]]=schedule
 for s in SOURCES:
  file=MEDIA/s[4];p=probe(file);v=[x for x in p['streams'] if x['codec_type']=='video'];a=[x for x in p['streams'] if x['codec_type']=='audio'];count=sum(x['channels'] for x in a);assert count==s[15],(s[0],count)
  if v:
   assert v[0]['r_frame_rate']=='25/1' and int(v[0]['nb_frames'])==round(float(s[7])*25)
   if s[8]=='None':assert not any(x.get('codec_tag_string')=='tmcd' for x in p['streams'])
   else:assert v[0]['tags']['timecode']==s[11],(s[0],v[0].get('tags'))
  else:
   assert bext_reference(file)==round(float(s[10])/FPS*SR)
  assert abs(float(p['format']['duration'])-float(s[7]))<1/SR
  result={'filename':s[4],'event_start_seconds':s[5],'event_stop_seconds':s[6],'duration_seconds':s[7],'video_frames':int(v[0]['nb_frames']) if v else 0,'recorded_timecode':s[11],'total_audio_channels':count,'audio_streams':len(a),'audio_lag_samples':round(float(s[13])*SR/FPS),'size_bytes':file.stat().st_size}
  if a:
   assert all(x['codec_name']=='pcm_s24le' and x['sample_rate']=='48000' for x in a)
   originals=sorted((WORK/s[0]).glob('A*.wav'));offset=0
   for streamix,st in enumerate(a):
    channels=st['channels'];actual=decoded_audio(file,streamix).reshape(-1,channels)
    for j in range(channels):
     expected=decoded_audio(originals[offset+j]);assert len(actual)==len(expected)==round(float(s[7])*SR)
     assert np.max(np.abs(actual[:,j]-expected))<1e-7,(s[0],offset+j)
    offset+=channels
   LOG['audio_checks'][s[0]]='All decoded channels match intended PCM samples and order'
  LOG['sources'][s[0]]=result
  print('Verified '+s[4],flush=True)
 # G delay is 2 frames = 3840 samples. Check its first ident against speech after the delay.
 assert LOG['sources']['G01']['audio_lag_samples']==3840
 # Check decoded key opacity before graphics, within graphics and after the changeover.
 key=[]
 for t in [0,20,60,100]:
  arr=np.frombuffer(ff('-ss',t,'-i',MEDIA/'GK01.mov','-frames:v','1','-pix_fmt','gray','-f','rawvideo','-').stdout,np.uint8)
  key.append((t,int(arr.min()),int(arr.max())))
 assert key[0][2]==0 and key[1][2]==255 and key[2][2]==0 and key[3][2]==255,key
 LOG['key_levels']=key
 # Confirm white camera flashes at event boundaries, including late-start B.
 for fid,local in [('A01',15),('B01',10),('D01',3),('G01',15)]:
  arr=np.frombuffer(ff('-ss',local,'-i',MEDIA/(fid+'.mov'),'-frames:v','1','-pix_fmt','gray','-f','rawvideo','-').stdout,np.uint8)
  assert arr.min()>245,(fid,arr.min())
 LOG['picture_sync']='White flashes checked at common event 15 seconds on A/B/D/G'
 LOG['programme_cuts']=[{'file_id':f,'event_start_seconds':a,'event_stop_seconds':b} for f,a,b in CUTS]
 (ROOT/'verification.json').write_text(json.dumps(LOG,indent=2)+'\n')
 print('All verification checks passed',flush=True)

def main():
 if not all((WORK/f'CAM_A_{i:02}.npy').exists() for i in range(1,17)):master_audio()
 else:LOG['buses']={'mix_minus_grams_vt':'checked during original master build','mix_minus_audience':'checked during original master build','pre_post_fader':'checked during original master build'}
 cams=[s for s in SOURCES if s[2]=='Camera']
 def complete_camera(s):
  if not (MEDIA/s[4]).exists():return False
  try:
   p=probe(MEDIA/s[4]);streams=p['streams'];vid=next(x for x in streams if x['codec_type']=='video')
   return int(vid['nb_frames'])==round(float(s[7])*25) and all(abs(float(x['duration'])-float(s[7]))<1/SR for x in streams if x['codec_type']=='audio')
  except (RuntimeError,KeyError,ValueError,StopIteration):return False
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  list(pool.map(camera,[s for s in cams if not complete_camera(s)]))
 for s in SOURCES:
  if s[2]=='Recorder':recorder(s)
 def complete_video(name,frames):
  try:
   p=probe(MEDIA/name);v=next(x for x in p['streams'] if x['codec_type']=='video');return int(v['nb_frames'])==frames
  except (RuntimeError,KeyError,StopIteration,ValueError):return False
 if not all(complete_video(name,4500) for name in ['GF01.mov','GK01.mov']):graphics()
 if not complete_video('P01.mov',4500) or not (ROOT/'Programme_Composite_Preview.mp4').exists():programme()
 verify()
 (ROOT/'manifest.json').write_text(json.dumps({'specification':'source_spec.json','resolution':[W,H],'fps':FPS,'event_duration_seconds':SECONDS,'speech':'FFmpeg Flite slt and rms','packing':'A/G separate mono streams; ordinary stereo one stereo stream; R01 interleaved 8-channel BWF','source_files':list(LOG['sources'].values()),'programme_sound':'Continuous clean Camera A main-mix buses with programme-specific utility idents','utility_ident_policy':'File ident at local 1 s. Channel idents at local 5 s then every 30 s; omit when a reserved cue/test window overlaps.'},indent=2)+'\n')
 print('FULL SET COMPLETE',flush=True)

if __name__=='__main__':main()
