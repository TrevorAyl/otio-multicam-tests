SYNTHETIC MULTICAMERA TEST SET

Extract every ZIP into the same directory. All archives use the same
Multicam_Full/ root. The 16 source files live in Media/.
Multicam_Source_Plan.xlsx is the source/channel map and timing specification.

SHARED EVENT CLOCK
  180 seconds, 1280 x 720 progressive, 25 fps.
  Event zero corresponds to 10:00:00:00 at 25 fps non-drop.
  Picture burn-ins show TRUE EVENT TC and RECORDED TC separately.
  Event coverage is start inclusive and stop exclusive. Do not close the
  intentional gaps in the stop/start cameras when making a group.

CAMERAS
  A01: 0-180 s; correct timecode; 16 separate mono PCM audio streams.
  B01: 5-175 s; correct timecode; one stereo PCM stream.
  C01: 0-65 s; C02: 80-180 s. Same angle CAM_C; TC reads 2 frames ahead.
  D01: 12-165 s; TC reads 2 frames behind; one stereo PCM stream.
  E01: 8-180 s; NO TIMECODE TRACK; align by waveform/visual cue/event clock.
  F01: 0-60 s; F02: 75-130 s; F03: 140-180 s. Same angle CAM_F.
       Every file's recorded TC resets to 00:00:00:00.
  G01: 0-180 s; correct picture TC; 12 separate mono PCM audio streams.
       All embedded sound, including local idents, is 2 frames (80 ms) late.
       Initial audio is padded with silence and the final 80 ms is truncated
       so picture/audio file duration remains 180 s.
  H01: 20-155 s; correct timecode; silent, no audio stream.
  Camera video is H.264 in MOV. Audio is 48 kHz / 24-bit PCM.
  A/G track labels are embedded as stream titles/handler names.
  Stereo pairs in the channel map are editorial relationships. Configure
  them explicitly in the NLE; A/G retain separate mono tracks in the files.

EXTERNAL AUDIO
  R01.wav: 0-180 s, one 8-channel interleaved PCM Broadcast WAV.
  R02.wav: 3-178 s, stereo Broadcast WAV; recorded TC reads 2 frames behind.
  Their BWF bext TimeReference fields contain sample counts from midnight:
    R01: 1728000000 samples (10:00:00:00).
    R02: 1728140160 samples (10:00:02:23).
  Channel count/order and time references are recorded in verification.json.
  R01 may initially be treated as surround audio by an NLE; set the intended
  eight discrete mono channels according to the workbook.

SPOKEN IDENTS AND SYNC
  File ident: local 1 s on each recorded channel (silent H excluded).
  Channel ident: local 5 s, then every 30 s when the entire phrase fits.
  An ident is omitted when it would overlap a protected sync or mix test.
  Exact applied ident positions are listed in verification.json.
  Speech uses FFmpeg Flite slt/rms voices, not real performers.
  Sync bursts at shared event 15, 45, 90 and 150 s use 1, 2, 3 and 4 pips.
  The first pip aligns with a one-frame full-white camera flash.
  Later pips are spaced by 160 ms. A spoken event label follows each burst.
  Scratch tracks and recorder sync channel share a deterministic,
  non-repeating bed generated on the whole event clock before file extraction.
  G's pip is deliberately 80 ms late relative to the picture flash.

STUDIO AUDIO
  A has the supplied 16-channel map; G has the supplied 12-channel map.
  Bob: 25-35 s. His post-fader contribution drops 12 dB during 28-32 s;
  A5 remains pre-fader. Jim: 95-105 s.
  Player 1: 55-65 s. Player 2: 115-125 s, with a 12 dB post-fader drop
  at 118-122 s while A10 remains pre-fader.
  Guest 1: 135-140 s; Guest 2: 155-160 s.
  Audience: 35-40 s; music: 65-75 s; VT: 100-110 s; VO: 160-170 s.
  Green room automix examples: left 75-83 s, right 125-133 s.
  Mix-minus Grams/VT excludes the actual music and VT buses.
  Mix-minus Audience excludes the actual audience buses.
  Spoken channel/file labels are injected AFTER deriving the studio mixes;
  compare mix arithmetic away from utility ident windows.
  Audio/music/audience are synthetic technical test signals, not production recordings.

GRAPHICS
  GF01.mov: straight colour fill; GK01.mov: matching greyscale opacity matte.
  Both: 0-180 s, ProRes 422 HQ 10-bit, 25 fps, TC 10:00:00:00, no audio.
  Graphics active during 10-50 s and 85-180 s. The second interval includes
  a moving frame counter with antialiased glyph edges.
  Matte polarity: black transparent, white opaque, grey partial coverage.
  Files are tagged video range / Rec.709. Normalise decoded matte black/white
  to 0/1 and use it as data, not a creative colour-graded picture.
  Neither source has an embedded alpha channel. Use the separate key as
  the fill's external luminance/opacity matte, not a chroma key.

PROGRAMME
  P01.mov: a switched video record with continuous stereo main-mix buses.
  Camera changes: A 0-20; B 20-40; C 40-60; D 60-90; C 90-120;
                  F 120-130; A 130-140; F 140-160; E 160-180.
  P01 uses the clean Camera A main-mix buses with programme-specific utility
  idents; it does not switch audio with the picture or copy A's utility labels.
  Source P01 has no graphics burned in. Programme_Composite_Preview.mp4
  shows the expected external-key/fill composite and carries stereo AAC sound.

VERIFICATION
  Decoded audio compared channel-by-channel against intended PCM sources.
  File frame counts, durations, sample counts, channel order, timecode and
  BWF time references checked. Mix-minus and fader relationships checked.
  Key levels and camera flashes checked. See verification.json.
  'Verified' in the workbook means these media checks passed.
  NLE import, channel interpretation, multicam grouping and interchange
  behaviour remain for testing; no native NLE project is supplied.

REGENERATION
  source_spec.json contains the exported source plan, audio map and cues.
  generate_all.py builds this set offline using FFmpeg/ffprobe, Python 3,
  numpy and Pillow. FFmpeg must include the flite, drawtext, alphamerge,
  alphaextract, overlay, libx264 and prores_ks filters/encoders.
  Run: python3 generate_all.py
  Outputs go to Media/, speech cache to Speech/, temporary audio to Work/.
  The generator reuses complete camera files and master buses when rerun.
  To apply changed audio/camera specifications, use a new folder containing
  the script and updated source_spec.json, without old Media/ or Work/ caches.
  Stereo channels are never converted to a surround mix during generation.
