"""Run: python migrate_selectors.py INPUT.otio OUTPUT.otio
Use package example for reference. Exported stable plain JSON fields, not runtime OTIO dependency."""
import json,sys
from pathlib import Path

def migrate(data):
    if 'selectors' in data: raise ValueError('Already migrated')
    data=json.loads(json.dumps(data)); data['selectors']=[]
    for ref in data['composition_references']:
        attrs=ref['attributes']; sid=ref['occurrence_id']
        selected=attrs.pop('selected'); alternatives=attrs.pop('alternatives')
        ref['selections'].pop('selected_source_slot',None)
        attrs['selector_id']=sid+':selection'
        data['selectors'].append(dict(OTIO_SCHEMA='MulticamSelector.1', selector_id=sid+':selection', occurrence_id=sid, stream='AAF_slot_'+str(attrs.get('aaf_slot_id')), selected=selected, alternatives=alternatives, timing=dict(duration_frames=ref['timing']['duration_frames'],source_in_frame=selected.get('start_frame'),rate=ref['timing'].get('rate')),provenance=dict(aaf_path=attrs.get('aaf_path'),component_kind=attrs.get('component_kind'), parent_definition_id=attrs.get('parent_definition_id'),aaf_slot_id=attrs.get('aaf_slot_id'))))
    for track in data['timeline']['tracks']['children']:
        for child in track['children']:
            meta=child.get('metadata',{}).get('org.otio_multicam_research.v07',{})
            if meta.get('occurrence_id'):
                meta['selector_id']=meta['occurrence_id']+':selection'
    data['version']='1.1-selector-separated'
    return data

if __name__=='__main__':
    d=migrate(json.loads(Path(sys.argv[1]).read_text()))
    Path(sys.argv[2]).write_text(json.dumps(d,indent=2)+'\n')
