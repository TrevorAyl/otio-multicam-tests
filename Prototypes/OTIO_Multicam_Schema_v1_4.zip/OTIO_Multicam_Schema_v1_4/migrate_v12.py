"""Deterministic v1.1 -> v1.2 OTIO SchemaDef JSON upgrade. Standard library only."""
import json,copy,sys
from pathlib import Path
PICTURE_SLOTS=[1,18,21,23,26,28,31,44,45,54,57]
def scope(s):
    slot=s['provenance'].get('aaf_slot_id')
    return s['selected']['definition_id'], {9:'picture',12:'audio_1',13:'audio_2'}.get(slot,'aaf_track_'+str(slot))
def migrate(document):
    if 'angle_definitions' in document or 'output_references' in document:raise ValueError('Already v1.2')
    d=copy.deepcopy(document)
    definitions={x['definition_id']:x for x in d['definitions']}
    groups={}
    for selector in d['selectors']:
        key=scope(selector)
        if key[0] not in definitions:raise ValueError('Unknown composition '+key[0])
        for alt in [selector['selected']]+selector['alternatives']:
            if alt['definition_id']!=key[0]:raise ValueError('Mismatched source composition')
            groups.setdefault(key,set()).add(int(alt['source_slot']))
    angles=[]; outputs={}; numbers={}
    for (defid,group),slots in sorted(groups.items()):
        ordered=sorted(slots,key=lambda v:(PICTURE_SLOTS.index(v) if v in PICTURE_SLOTS else 1000+v) if group=='picture' else v)
        numbers[(defid,group)]={v:i+1 for i,v in enumerate(ordered)}
        for order,slot in enumerate(ordered,1):
            output_id=defid+'#slot-'+str(slot)
            if output_id not in outputs:
                layer=next((x for x in definitions[defid]['layers'] if x.get('slot_id')==slot),None)
                source={'kind':'composition_slot','slot_id':slot,'media_sources':copy.deepcopy(layer.get('media_sources',[])) if layer else []}
                outputs[output_id]=dict(OTIO_SCHEMA='OutputReference.1', output_ref_id=output_id,definition_id=defid,output_type=('picture' if group=='picture' else 'sound' if group.startswith('audio_') else 'unknown'),source=source,provenance={'aaf_source_slot':slot})
            angles.append(dict(OTIO_SCHEMA='AngleDefinition.1', angle_id=order,definition_id=defid,group_id=group,display_order=order,output_ref_id=output_id,label=str(slot),provenance={'aaf_source_slot':slot}))
    d['angle_definitions']=angles
    d['output_references']=list(outputs.values())
    for selector in d['selectors']:
        defid,group=scope(selector)
        mapping=numbers[(defid,group)]
        selected=int(selector['selected']['source_slot'])
        selector['portable_selection']={'definition_id':defid,'group_id':group,'angle_id':mapping[selected], 'output_ref_id':defid+'#slot-'+str(selected),'alternative_angle_ids':[mapping[int(a['source_slot'])] for a in selector['alternatives']]}
    d['version']='1.2-numeric-angle-ids'
    return d
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python migrate_v12.py source-v11.otio target-v12.otio')
    Path(sys.argv[2]).write_text(json.dumps(migrate(json.loads(Path(sys.argv[1]).read_text())),indent=2)+'\n')
