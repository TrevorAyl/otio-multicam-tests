"""Native OTIO plugin integration and value-based, round-trip validation.

OTIO's AnyDictionary/AnyVector wrappers should not be compared by Python
object equality. Compare the JSON produced by the native serializer instead.
"""
import json
import os
from pathlib import Path
import opentimelineio as otio

root = Path(__file__).resolve().parent
assert os.getenv('OTIO_PLUGIN_MANIFEST_PATH'), 'Set OTIO_PLUGIN_MANIFEST_PATH to manifest.json'
source = root / 'avid_multicam_v12.otio'
output = root / 'avid_multicam_v12_roundtrip.otio'

original = otio.adapters.read_from_file(str(source))
assert type(original).__name__ == 'MulticamPackage'
assert (len(original.selectors), len(original.media), len(original.definitions),
        len(original.composition_references)) == (79, 16, 3, 79)
assert original.angle_definitions and original.output_references
assert type(original.angle_definitions[0]).__name__ == 'AngleDefinition'
assert type(original.output_references[0]).__name__ == 'OutputReference'

# Read -> write -> read using the actual OTIO runtime.
otio.adapters.write_to_file(original, str(output))
reloaded = otio.adapters.read_from_file(str(output))
assert type(reloaded).__name__ == 'MulticamPackage'
for field in ('selectors', 'media', 'definitions', 'composition_references',
              'angle_definitions', 'output_references', 'operations'):
    lhs = len(getattr(original, field))
    rhs = len(getattr(reloaded, field))
    assert lhs == rhs, f'{field} count changed: {lhs} -> {rhs}'

# The JSON payload is a reliable value representation independent of the
# Python bindings' C++ wrapper equality semantics.
original_json = json.loads(source.read_text(encoding='utf-8'))
roundtrip_json = json.loads(output.read_text(encoding='utf-8'))

def by_id(document, collection, id_field):
    out = {}
    key_fields = (id_field,) if isinstance(id_field, str) else tuple(id_field)
    for obj in document[collection]:
        identifier = tuple(obj[field] for field in key_fields)
        if len(identifier) == 1:
            identifier = identifier[0]
        if identifier in out:
            raise AssertionError(f'duplicate {collection} {id_field}={identifier!r}')
        out[identifier] = obj
    return out

def compare_fields(collection, id_field, fields):
    aa = by_id(original_json, collection, id_field)
    bb = by_id(roundtrip_json, collection, id_field)
    assert aa.keys() == bb.keys(), (
        f'{collection} identities changed: removed={sorted(aa.keys()-bb.keys())[:5]}, '
        f'added={sorted(bb.keys()-aa.keys())[:5]}')
    for key in aa:
        for field in fields:
            before = aa[key].get(field)
            after = bb[key].get(field)
            if before != after:
                raise AssertionError(
                    f'{collection}[{key!r}].{field} changed:\n'
                    f'BEFORE: {json.dumps(before, sort_keys=True)[:1200]}\n'
                    f'AFTER:  {json.dumps(after, sort_keys=True)[:1200]}')

compare_fields('selectors', 'selector_id',
               ('portable_selection', 'selected', 'alternatives', 'timing', 'occurrence_id', 'stream'))
compare_fields('angle_definitions', ('definition_id', 'group_id', 'angle_id'),
               ('angle_id', 'definition_id', 'group_id', 'display_order', 'provenance'))
compare_fields('output_references', 'output_ref_id',
               ('definition_id', 'output_type', 'source', 'provenance'))

print('OTIO v1.2 SchemaDef read/write/read PASSED:', output)
print('All 79 portable selections and their original selected/alternative sources preserved.')
print('All angle definitions and output references preserved by value.')
