import unittest,json,copy
from pathlib import Path
from recursive_resolver import Resolver,ResolutionError
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'nested_recursive_typed.otio').read_text())

class Tests(unittest.TestCase):
    def test_typed_fixture(self):
        self.assertEqual(len(D['composite_outputs']),2)
        self.assertEqual({x['OTIO_SCHEMA'] for x in D['composite_outputs']},{'CompositeOutput.1'})
    def test_fourbox_independent(self):
        r=Resolver(D)
        a=r.evaluate_edit('edit_1')['result']['inputs']
        b=r.evaluate_edit('edit_2')['result']['inputs']
        self.assertEqual([a[k]['angle_id'] for k in ('top_left','top_right','bottom_left','bottom_right')],[1,2,1,2])
        self.assertEqual([b[k]['angle_id'] for k in ('top_left','top_right','bottom_left','bottom_right')],[2,1,2,1])
        self.assertEqual([x['angle_id'] for x in D['angle_definitions'] if x['definition_id']=='MC_INNER'],[1,2])
    def test_graphics_output(self):
        r=Resolver(D)
        out=r.resolve_occurrence('outer_graphic')
        self.assertEqual(out['operation'],'external_matte')
        self.assertEqual(out['inputs']['fill']['media_id'],'GF01')
        self.assertEqual(out['inputs']['matte']['media_id'],'GK01')
        self.assertEqual(out['alpha_mode'],'straight')
    def test_audio_cuts_independent(self):
        audio=[s for s in D['selectors'] if s['stream']=='audio_1']
        video=[s for s in D['selectors'] if s['stream']=='picture']
        self.assertEqual([(s['timing']['start_frame'],s['timing']['duration_frames']) for s in audio],[(0,75),(75,25)])
        self.assertEqual([(s['timing']['start_frame'],s['timing']['duration_frames']) for s in video],[(0,50),(50,50)])
    def test_missing_media_rejected(self):
        d=copy.deepcopy(D);d['media']=[m for m in d['media'] if m['media_id']!='GF01']
        with self.assertRaisesRegex(ResolutionError,'missing media'):Resolver(d).resolve_occurrence('outer_graphic')
    def test_cycle_rejected(self):
        d=copy.deepcopy(D)
        next(x for x in d['composition_references'] if x['occurrence_id']=='quad_TL')['definition_id']='MC_OUTER'
        next(x for x in d['composition_references'] if x['occurrence_id']=='quad_TL')['selections']={'picture':1}
        with self.assertRaisesRegex(ResolutionError,'cyclic definition'):Resolver(d).evaluate_edit('edit_1')
    def test_invalid_angle_rejected(self):
        d=copy.deepcopy(D)
        next(x for x in d['composition_references'] if x['occurrence_id']=='edit_1')['selections']['picture']=999
        with self.assertRaisesRegex(ResolutionError,'unknown angle'):Resolver(d).evaluate_edit('edit_1')
    def test_no_shared_mutation(self):
        before=json.dumps(D,sort_keys=True)
        r=Resolver(D);r.evaluate_edit('edit_1');r.evaluate_edit('edit_2')
        self.assertEqual(before,json.dumps(D,sort_keys=True))
    def test_aaf_regression(self):
        a=json.loads((ROOT/'avid_multicam_v12.otio').read_text())
        assert (len(a['selectors']),len(a['definitions']),len(a['media']))==(79,3,16)
        self.assertEqual(sum(x['OTIO_SCHEMA']=='MulticamSelector.1' for x in a['selectors']),79)

if __name__=='__main__':unittest.main()
