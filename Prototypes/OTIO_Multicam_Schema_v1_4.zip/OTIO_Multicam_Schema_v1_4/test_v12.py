import unittest,json,copy
from pathlib import Path
from migrate_v12 import migrate
r=Path(__file__).resolve().parent
old=json.loads((r/'avid_multicam_v11_baseline.otio').read_text())
new=json.loads((r/'avid_multicam_v12.otio').read_text())
class TestV12(unittest.TestCase):
 def test_reproducibility(self):self.assertEqual(migrate(old),new)
 def test_counts(self):self.assertEqual((len(new['selectors']),len(new['media']),len(new['definitions']),len(new['composition_references'])),(79,16,3,79))
 def test_timeline_unchanged(self):self.assertEqual(old['timeline'],new['timeline'])
 def test_original_provenance_unchanged(self):
  for a,b in zip(old['selectors'],new['selectors']):
   for key in ('selected','alternatives','timing','provenance','occurrence_id','stream'):self.assertEqual(a[key],b[key])
 def test_all_old_core_objects_unchanged(self):
  for k in ('media','composition_references','definitions','operations'):self.assertEqual(old[k],new[k])
 def test_angle_numbers_scoped(self):
  groups={}
  for a in new['angle_definitions']:
   self.assertIsInstance(a['angle_id'],int)
   groups.setdefault((a['definition_id'],a['group_id']),[]).append(a['angle_id'])
  for values in groups.values():self.assertEqual(sorted(values),list(range(1,len(values)+1)))
  self.assertTrue(any(k[1]=='picture' for k in groups))
  self.assertTrue(any(k[1]=='audio_1' for k in groups))
 def test_selected_angle_resolves(self):
  index={(a['definition_id'],a['group_id'],a['angle_id']):a for a in new['angle_definitions']}
  for s in new['selectors']:
   p=s['portable_selection']; a=index[(p['definition_id'],p['group_id'],p['angle_id'])]
   self.assertEqual(a['provenance']['aaf_source_slot'],s['selected']['source_slot'])
   self.assertEqual(len(p['alternative_angle_ids']),len(s['alternatives']))
 def test_output_references_resolve(self):
  out={o['output_ref_id'] for o in new['output_references']}
  self.assertEqual(len(out),len(new['output_references']))
  self.assertTrue(all(a['output_ref_id'] in out for a in new['angle_definitions']))
 def test_picture_numbers(self):
  p={a['provenance']['aaf_source_slot']:a['angle_id'] for a in new['angle_definitions'] if a['group_id']=='picture'}
  self.assertEqual((p[1],p[18],p[21]),(1,2,3))
 def test_graphics_preserved(self):self.assertEqual(old['operations'],new['operations'])
 def test_bad_definition_rejected(self):
  bad=copy.deepcopy(old);bad['selectors'][0]['selected']['definition_id']='bad'
  with self.assertRaises(ValueError):migrate(bad)
if __name__=='__main__':unittest.main()
