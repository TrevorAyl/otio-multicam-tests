# OTIO Multicam Schema v1.3 — Recursive composite output proof of concept

**Status:** Experimental SchemaDef prototype; not upstream OTIO, not an NLE renderer.
Built from the **Mac-validated v1.2b** baseline without modifying it.

## New typed class

`CompositeOutput.1` identifies a named output port on a composition, with `owner_definition_id`, `stream_kind`, `operation_id`, `channels`, `alpha_mode` and attributes. `MulticamPackage.1` gains an optional `composite_outputs` collection. Original v1.2 Avid data is retained unchanged; absent new fields are accepted by the importer.

## Typed recursive fixture

`nested_recursive_typed.otio` includes all objects as serialized, registered OTIO SchemaDef types, rather than a conceptual standalone JSON example. It represents:

- `MC_INNER`: stable numeric angle IDs 1 and 2, each resolving to a relinkable source.
- `FOUR_BOX`: four simultaneous *occurrences* of `MC_INNER`; 2x2 spatial composite with one picture output.
- `GRAPHICS`: fill GF01 + key GK01 combined with an external luma matte to one straight-alpha RGBA output.
- `MC_OUTER`: angle 1 selects the four-box output; angle 2 selects the keyed graphics output.
- Two *separate* edited occurrences of `MC_OUTER`, each selecting outer angle 1 with **different per-occurrence inner angle selections**, without mutating shared definitions.
- Picture cuts at frame 50, audio independently cuts at frame 75.

The resolver (`recursive_resolver.py`) evaluates **symbolic graph structure**. It does **not** calculate pixels, audio samples or actual spatial transforms. The external-matte semantics are fully explicit in the proposed fixture (not inferred from Avid's opaque OperationGroup). It does not yet implement frame propagation through timewarps.

## On your Mac

```bash
source ~/otio-python/bin/activate
python -m unittest discover -p 'test*.py' -v
export OTIO_PLUGIN_MANIFEST_PATH="$PWD/manifest.json"
python check_v13_runtime.py
python recursive_resolver.py
```

The native integration test covers the Mac-validated v1.2 Avid file and the new typed recursive fixture. No import into Avid, Premiere or Resolve is implied.

## Design questions before upstream proposal

1. Should named composite outputs live on definitions, on operations, or both? Here they are registered as typed records owned by definitions.
2. Should `CompositionReference` carry an output port choice, or should it consume an explicit `OutputReference` as modeled here?
3. Precise syntax for occurrence-path selection overrides, definition vs occurrence default selection, and nested timebase mapping.
4. Standardised fill/key alpha and multi-layer transforms versus opaque effects fallback.
5. Whether shared definitions should be serialized in a global document registry or embedded as stack content with stable cross-object references.

**Limitations:** sample graph uses declared IDs; `spatial_grid` transform parameters are placeholders. Cycles, missing IDs, missing selected angle, invalid alternatives should fail closed. Full AAF write is still a separate implementation milestone.
