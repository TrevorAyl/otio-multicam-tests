# v1.2b runtime comparison correction

The v1.2a runtime comparison incorrectly used `output_ref_id` to uniquely identify an `AngleDefinition`. Multiple angles in different selector groups can deliberately map to the same physical output, so the assertion `duplicate angle_definitions output_ref_id=...` is expected and does **not** indicate corrupt data.

The revised check uses the composite key `(definition_id, group_id, angle_id)` for angle definitions. `output_ref_id` is still a unique key for the output-reference registry itself. Selector identity remains `selector_id`.

The check still compares actual persisted values (rather than comparing OTIO's wrapped C++ dictionaries for equality). Only the lookup key was corrected. This does not modify any schema classes or Avid-derived data.

Run:

```sh
source ~/otio-python/bin/activate
export OTIO_PLUGIN_MANIFEST_PATH="$PWD/manifest.json"
python check_otio_runtime.py
```

The native OTIO read/write/read check must run on a machine with OpenTimelineIO installed. All static migration regression tests can be run with `python -m unittest discover -p 'test*.py' -v`.
