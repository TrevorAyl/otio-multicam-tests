import unittest
from nested_example import example
class TestNested(unittest.TestCase):
 def test_angle_scope(self):
  e=example();d={a['id']:a for a in e['definitions']}
  self.assertEqual([a['angle_id'] for a in d['MC_INNER']['angles']],[1,2])
  self.assertEqual([a['angle_id'] for a in d['MC_OUTER']['angles']],[1,2])
 def test_same_definition_different_inner_selections(self):
  a,b=example()['edited_picture_segments'];self.assertEqual(a['definition_id'],b['definition_id']);self.assertNotEqual(a['nested_selections'],b['nested_selections'])
 def test_fixed_selection_and_independent_audio_cut(self):
  e=example();self.assertEqual([x['start_frame'] for x in e['edited_picture_segments']],[0,50]);self.assertEqual([x['start_frame'] for x in e['edited_audio_segments']],[0,75])
 def test_composite_outputs(self):
  e=example();ref={x['id']:x for x in e['output_references']};self.assertEqual(ref['RGBA_GRAPHIC']['definition_id'],'KEYED_GRAPHIC')
if __name__=='__main__':unittest.main()
