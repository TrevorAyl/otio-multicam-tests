"""Run only with OTIO plugin manifest set. Compare native serialized values."""
import json,os
from pathlib import Path
import opentimelineio as otio
root=Path(__file__).parent
assert os.environ.get('OTIO_PLUGIN_MANIFEST_PATH'), 'Set plugin manifest env var'
for name in ('avid_multicam_v12.otio','nested_recursive_typed.otio'):
    p=root/name
    obj=otio.adapters.read_from_file(str(p))
    assert type(obj).__name__=='MulticamPackage'
    if name.startswith('nested_'):
        assert len(obj.composite_outputs)==2
        assert type(obj.composite_outputs[0]).__name__=='CompositeOutput'
    else:
        assert (len(obj.selectors),len(obj.media))==(79,16)
    out=root/(p.stem+'_native_roundtrip.otio')
    otio.adapters.write_to_file(obj,str(out))
    reloaded=otio.adapters.read_from_file(str(out))
    a=json.loads(p.read_text());b=json.loads(out.read_text())
    for field in ('definitions','composition_references','selectors','angle_definitions','output_references','composite_outputs','operations'):
        assert a.get(field,[])==[{k:v for k,v in e.items() if k in e} for e in b.get(field,[])] or all(
            all(k in returned and returned[k]==v for k,v in original.items())
            for original,returned in zip(a.get(field,[]),b.get(field,[]))
        ), f'{name}: field mismatch {field}'
    assert len(reloaded.definitions)==len(obj.definitions)
    print('PASS',name,'->',out.name)
print('OTIO v1.3 native read/write/read PASSED')
