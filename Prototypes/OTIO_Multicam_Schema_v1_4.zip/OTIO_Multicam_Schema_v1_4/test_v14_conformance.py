import json
import unittest
from pathlib import Path
from conformance_report import audit

ROOT=Path(__file__).resolve().parent

class ConformanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.doc=json.loads((ROOT/'nested_recursive_typed.otio').read_text())
        cls.cfg=json.loads((ROOT/'CAPABILITIES.json').read_text())

    def test_features(self):
        flags=audit(self.doc,self.cfg['example_adapter'])['features_detected']
        for f in ('shared_definitions','recursive_nesting','occurrence_local_nested_selections',
                  'multiple_simultaneous_instances','spatial_composite','external_matte','alpha_output'):
            self.assertIn(f,flags)

    def test_no_false_native_import_claim(self):
        result=audit(self.doc,self.cfg['example_adapter'])
        self.assertFalse(result['native_editable_import_claim_allowed'])
        self.assertFalse(result['flattening_permitted_automatically'])
        self.assertIn('external_matte',result['unsupported_native_features'])

    def test_complete_capability_claim_is_not_renderer_proof(self):
        profile={'name':'declared_all','supports':self.cfg['capabilities']}
        result=audit(self.doc,profile)
        self.assertTrue(result['native_editable_import_claim_allowed'])
        self.assertFalse(result['flattening_permitted_automatically'])

    def test_v13_plugin_is_unchanged_in_v14(self):
        import hashlib
        old=Path('/mnt/data/OTIO_Multicam_Schema_v1_3/multicam_schemadef.py')
        if old.exists():
            self.assertEqual(hashlib.sha256(old.read_bytes()).hexdigest(),hashlib.sha256((ROOT/'multicam_schemadef.py').read_bytes()).hexdigest())

    def test_ai_disclosure_in_public_docs(self):
        for filename in ('SPECIFICATION_DRAFT.md','README_V14.md','GITHUB_DISCUSSION_DRAFT.md'):
            self.assertIn('ChatGPT', (ROOT/filename).read_text())

    def test_source_fixture_counts(self):
        self.assertEqual(len(self.doc['definitions']),4)
        self.assertEqual(len(self.doc['composite_outputs']),2)

if __name__=='__main__': unittest.main()
