# OTIO Multicam experimental SchemaDef v1.2

**Purpose:** demonstrate portable **numeric** angle IDs, typed output references, fixed per-edit selectors, independently edited audio, and retention of native AAF source-slot identity. This is an experimental OTIO plugin, **not an upstream OTIO schema**. v1.1 successfully passed the real OTIO runtime on macOS; **v1.2's runtime test has not yet been run**.

## Contents

- `multicam_schemadef.py` / `manifest.json`: OTIO SchemaDef plugin with existing v1.1 classes and new `AngleDefinition.1`, `OutputReference.1`.
- `avid_multicam_v11_baseline.otio`: unchanged working input fixture.
- `avid_multicam_v12.otio`: Avid-derived fixture with numeric angle and output objects.
- `migrate_v12.py`: deterministic upgrade preserving all v1.1 editorial/source fields.
- `nested_numeric_example.json` / `nested_example.py`: **conceptual** outer-multicam, inner-multicam, four-box and keyed-graphics case with independent nested selections; intentionally **not** a runnable OTIO object graph.
- `test_v12.py`, `test_nested_example.py`, `check_otio_runtime.py`: local tests and real OTIO runtime verification.

## Mac validation

From this directory with your existing `~/otio-python` virtual environment:

```bash
source ~/otio-python/bin/activate
python -m unittest discover -p 'test*.py' -v
export OTIO_PLUGIN_MANIFEST_PATH="$PWD/manifest.json"
python check_otio_runtime.py
```

Expected last line: `OTIO v1.2 SchemaDef read/write/read PASSED`.

If you get a traceback, share it verbatim. Do not assume that JSON tests establish native OTIO compatibility.

## Semantics

- `AngleDefinition.angle_id` is an integer starting at **1**, scoped by **(definition_id, group_id)**. Picture and each Avid audio track have separate scopes. `display_order` is distinct from stable identity.
- `OutputReference.output_ref_id` names an output of a composition slot, not the same thing as an angle or an edit occurrence. Its `source` retains associated source media references.
- `MulticamSelector.portable_selection` is an additional portable projection of a v1.1 selector. Original `selected`, `alternatives`, `timing` and `provenance` remain unchanged and authoritative for reconstruction of the original AAF. Every selection is fixed for one edit segment; cut locations are unchanged.
- Media identities, locators, source timecodes, AAF MobIDs, graphics opaque operation and all source offsets remain unchanged.
- Audio alternatives are not rebranded as picture angles. The `group_id` identifies an independent selection domain. Its numbered items are *source output choices*, not guaranteed camera angles.

### Verified picture mapping for this Avid fixture

| Portable angle ID | Original AAF backing slot |
|---:|---:|
| 1 | 1 |
| 2 | 18 |
| 3 | 21 |
| 4 | 23 |
| 5 | 26 |
| 6 | 28 |
| 7 | 31 |
| 8 | 44 |
| 9 | 45 |
| 10 | 54 |
| 11 | 57 |

**Caution:** the last list includes fill/key outputs; this numbering is a *portable view of Avid's candidate picture slots*, **not a claim about Avid's UI angle numbers or picture semantics of all 11 slots**. Fully interpreting the graphics as a single nested composite angle remains future work. Values use the current exported candidate ordering, and source/source-range accuracy is preserved in AAF provenance.

## Remaining work

1. Verify v1.2 against real installed OTIO (new classes and fields can produce runtime incompatibilities).
2. Determine source-defined stable angle identities that don't rely on AAF slot ordering, and establish whether graphics fill/key must share a single nested output.
3. Replace ad-hoc source output payload with recursively resolvable OTIO composition references and defined ownership, cycle rules and timing.
4. Implement portable spatial/effect operations and a new-media AAF writer; structural JSON tests do **not** prove NLE interoperability.
