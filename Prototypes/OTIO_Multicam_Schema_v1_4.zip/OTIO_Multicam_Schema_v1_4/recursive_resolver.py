"""Experimental semantic resolver, NOT a renderer or timewarp engine.
Runs on JSON representation of typed OTIO SchemaDef objects (no OTIO import needed).
"""
import json
from pathlib import Path

class ResolutionError(ValueError): pass

class Resolver:
    def __init__(self, doc):
        self.doc=doc
        self.defs=self._index('definitions','definition_id')
        self.refs=self._index('composition_references','occurrence_id')
        self.ops=self._index('operations','operation_id')
        self.outputs=self._index('output_references','output_ref_id')
        self.ports=self._index('composite_outputs','output_id')
        self.media=self._index('media','media_id')
        self.angles={}
        for a in doc['angle_definitions']:
            key=(a['definition_id'],a['group_id'],a['angle_id'])
            if key in self.angles: raise ResolutionError(f'duplicate angle {key}')
            self.angles[key]=a
        for source, target in ((a['definition_id'],'definition') for a in doc['angle_definitions']):
            if source not in self.defs: raise ResolutionError(f'missing {target} {source}')

    def _index(self, field, key):
        out={}
        for obj in self.doc.get(field,[]):
            id=obj[key]
            if id in out: raise ResolutionError(f'duplicate {field}: {id}')
            out[id]=obj
        return out

    def resolve_occurrence(self, occurrence_id, overrides=None, path=(), stack=()):
        if occurrence_id not in self.refs: raise ResolutionError(f'unknown occurrence {occurrence_id}')
        ref=self.refs[occurrence_id]
        def_id=ref['definition_id']
        if def_id not in self.defs: raise ResolutionError(f'unknown definition {def_id}')
        if def_id in stack: raise ResolutionError('cyclic definition references: '+ ' -> '.join(stack+(def_id,)))
        definition=self.defs[def_id]
        selection=ref.get('selections',{}).copy()
        overrides=overrides or {}
        selection.update(overrides.get(path,{}))
        if definition['kind']=='multicam':
            angle=selection.get('picture')
            if angle is None: raise ResolutionError(f'missing picture selection for {occurrence_id}')
            k=(def_id,'picture',angle)
            if k not in self.angles: raise ResolutionError(f'unknown angle {k}')
            output=self.angles[k]['output_ref_id']
            return {'kind':'selected','definition_id':def_id,'occurrence_id':occurrence_id,'angle_id':angle,
                    'result':self.resolve_output(output,overrides,path,stack+(def_id,))}
        if definition['kind']=='composite':
            ports=[p for p in self.ports.values() if p['owner_definition_id']==def_id]
            if len(ports)!=1: raise ResolutionError(f'expected one named output for {def_id}')
            return self.resolve_port(ports[0]['output_id'],overrides,path,stack+(def_id,))
        raise ResolutionError(f'unsupported composition kind {definition["kind"]}')

    def resolve_output(self, output_id, overrides, path, stack):
        if output_id not in self.outputs: raise ResolutionError('missing output: '+ output_id)
        output=self.outputs[output_id]; src=output['source']
        if src['kind']=='media':
            if src['media_id'] not in self.media: raise ResolutionError('missing media: '+src['media_id'])
            return {'kind':'media','media_id':src['media_id'],'stream':src.get('stream','picture')}
        if src['kind']=='composite_output':
            return self.resolve_port(src['output_id'],overrides,path,stack)
        raise ResolutionError('unsupported output kind '+str(src['kind']))

    def resolve_port(self, output_id, overrides, path, stack):
        if output_id not in self.ports: raise ResolutionError('missing composite output: '+output_id)
        port=self.ports[output_id];opid=port['operation_id']
        if opid not in self.ops: raise ResolutionError('missing operation '+opid)
        op=self.ops[opid]
        result={}
        for role,target in op['inputs'].items():
            if op['operation_type']=='spatial_grid':
                # path uniquely identifies a child occurrence under this parent occurrence.
                # output 'OUT_QUAD' is reached from 'outer_quad'; match specific path.
                child_path=path+('outer_quad',target)
                result[role]=self.resolve_occurrence(target,overrides,child_path,stack)
            else:
                result[role]=self.resolve_output(target,overrides,path,stack)
        return {'kind':'composite','output_id':output_id,'operation':op['operation_type'],
                'alpha_mode':port['alpha_mode'],'parameters':op['parameters'],'inputs':result}

    def evaluate_edit(self, edit_id):
        ref=self.refs[edit_id]
        # Paths are stable occurrence IDs scoped to this individual edit; never mutate shared definitions.
        local={tuple(k.split('/')):v for k,v in ref.get('nested_selections',{}).items()}
        return self.resolve_occurrence(edit_id,local,(),())

if __name__=='__main__':
    doc=json.loads((Path(__file__).parent/'nested_recursive_typed.otio').read_text())
    r=Resolver(doc)
    for name in ('edit_1','edit_2'):
        print(name, json.dumps(r.evaluate_edit(name),sort_keys=True))
