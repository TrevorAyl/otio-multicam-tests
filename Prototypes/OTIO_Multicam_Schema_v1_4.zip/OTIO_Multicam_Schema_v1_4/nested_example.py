"""Pure JSON synthetic case illustrating numeric angles, nested occurrences and compositing.
Not an NLE export or a direct OTIO timeline; it documents intended semantics.
"""
import json
from pathlib import Path

def example():
 return {
  'note':'Conceptual recursive fixture, not an OTIO .otio file',
  'definitions':[
   {'id':'MC_INNER','kind':'multicam','angles':[
    {'angle_id':1,'display_order':1,'output_ref':'INNER_CAM_1'},
    {'angle_id':2,'display_order':2,'output_ref':'INNER_CAM_2'}]},
   {'id':'FOUR_BOX','kind':'composite','layers':[
    {'occurrence_id':'box_TL','definition_id':'MC_INNER','transform':'top_left'},
    {'occurrence_id':'box_TR','definition_id':'MC_INNER','transform':'top_right'},
    {'occurrence_id':'box_BL','definition_id':'MC_INNER','transform':'bottom_left'},
    {'occurrence_id':'box_BR','definition_id':'MC_INNER','transform':'bottom_right'}]},
   {'id':'KEYED_GRAPHIC','kind':'composite','operation':{
     'kind':'external_matte','fill':'GF01','matte':'GK01','output_ref':'RGBA_GRAPHIC'}},
   {'id':'MC_OUTER','kind':'multicam','angles':[
     {'angle_id':1,'display_order':1,'output_ref':'FOUR_BOX_RGBA'},
     {'angle_id':2,'display_order':2,'output_ref':'RGBA_GRAPHIC'}]}
  ],
  'output_references':[
   {'id':'INNER_CAM_1','kind':'media','media_id':'B01','stream':'picture'},
   {'id':'INNER_CAM_2','kind':'media','media_id':'B02','stream':'picture'},
   {'id':'FOUR_BOX_RGBA','kind':'composition','definition_id':'FOUR_BOX','stream':'picture'},
   {'id':'RGBA_GRAPHIC','kind':'composition','definition_id':'KEYED_GRAPHIC','stream':'picture'}
  ],
  'edited_picture_segments':[
   {'start_frame':0,'duration_frames':50,'occurrence_id':'outer_first','definition_id':'MC_OUTER',
    'selected_angle_id':1,'nested_selections':{'box_TL':1,'box_TR':2,'box_BL':1,'box_BR':2}},
   {'start_frame':50,'duration_frames':50,'occurrence_id':'outer_second','definition_id':'MC_OUTER',
    'selected_angle_id':1,'nested_selections':{'box_TL':2,'box_TR':1,'box_BL':2,'box_BR':1}}
  ],
  'edited_audio_segments':[
   {'start_frame':0,'duration_frames':75,'stream':'audio_1','source':'boom'},
   {'start_frame':75,'duration_frames':25,'stream':'audio_1','source':'mix'}
  ]
 }
if __name__=='__main__':Path('nested_numeric_example.json').write_text(json.dumps(example(),indent=2)+'\n')
